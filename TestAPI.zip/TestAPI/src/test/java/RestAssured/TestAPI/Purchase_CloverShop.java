package RestAssured.TestAPI;

import java.io.FileReader;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;


public class Purchase_CloverShop extends RestAssured_Functions{ 
	
		@Test
		public void create_MerchantData() throws  Exception {
		FileReader reader=new FileReader("../TestAPI/PurchaseClovershop.properties");
		Properties prop = new Properties();
		prop.load(reader);
		
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader("../TestAPI/POST_PurchaseEndpoint.json"));
        JSONObject jsonObject =  (JSONObject) obj;
        System.out.println(jsonObject);
		
		RestAssured_Functions RA = new RestAssured_Functions();
		
        RA.ExtractNodeFromResponse(prop.getProperty("nodetext"));
        jsonObject.replace("shopIntegrationToken", shopIntegrationToken);
        System.out.println("After replacing "+ jsonObject);
        RA.BaseURL(prop.getProperty("url5"));
        RA.Request();
        RA.Requestheader(prop.getProperty("Header1"),prop.getProperty("Content-Type"));
	    //RA.Requestheader(prop.getProperty("Header2"),prop.getProperty("Authorization"));
        RA.RequestbodytypeJson(jsonObject);
    	RA.Response_POST(prop.getProperty("url6"));
    	System.out.println(RA.Responsestatuscode());
		System.out.println("TC4 Done");
		

}
}
