package Selenium.TestScript;

import org.testng.annotations.Test;

import PageObjectModel.clover.CloverShop;
import Selenium.Driver.BaseDriver;
import Selenium.Driver.Selenium_Functions;;

public class CloverShopApplication extends BaseDriver {

	@Test
	public void FiservCloverShop() throws InterruptedException {
		System.out.println("Inside Fiser_Clover_Integration");
		
		BaseDriver bd = new BaseDriver();
		Selenium_Functions fc = new Selenium_Functions();
		bd.DriverSetup();
		CloverShop cs = new CloverShop(driver);
		
		fc.Maximize_Window(driver);
		fc.DeleteAll_Cookies(driver);
		fc.ImplicitWait(driver, 20);
		fc.LaunchURL_Browser(driver, "https://dev1.dev.clover.com?userLinkToken=" + shopIntegrationToken);
		
		cs.ShopNow().click();
		cs.ShopFlex().click();
		fc.KeyPress_Event(driver);
		cs.BuyNow().click();
		fc.KeyPress_Event(driver);
		cs.AddToCart().click(); 
		cs.ContinueToCart().click(); 
		cs.Next().click();
		cs.Email().sendKeys("vigneshselvam@virtusa.com");
		cs.MotherMaidenName().sendKeys("Jasmin"); cs.Continue().click();
		cs.ICertify().click();
		cs.Continue().click();
		cs.AddressLine1().sendKeys("Newbury St"); cs.StateName().sendKeys("Boston");
		cs.Zip().sendKeys("10001"); fc.DropDown_Selector(driver, cs.StateCode, "MA");
		cs.LastContinue().click();

	}
}
