package RestAssured.TestAPI;

import java.util.Random;

public class Utility {

	public int random() {
		Random rand = new Random();
		int rand_int1 = rand.nextInt(100000000);
		// ystem.out.println("Random Integers: "+rand_int1);
		return rand_int1;
	}

}
