package RestAssured.TestAPI;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;



public class RestAssured_Functions {

	public static JSONObject requestParams = new JSONObject();
	public static RequestSpecification httpRequest;
	public static Response response;
	public static ResponseBody body;	
	public static JsonPath jsonPathEvaluator;
	public static String  shopIntegrationToken;
	


	public void BaseURL(String url) {
		RestAssured.port = 8080;

	}

	public void Request() {
		httpRequest = RestAssured.given();
	}

	public void Requestbody_StringInt(String attribute, int value) {
		requestParams.put(attribute, value);
	}

	public void Requestbody_StringString(String attribute, String value) {
		requestParams.put(attribute, value);
	}
	
	/*
	 * public void Requestbody_Json(JsonObject jsonObject) {
	 * requestParams.put(jsonObject, jsonObject); }
	 */

	public void Requestheader(String attribute2, String value2) {
		httpRequest.header(attribute2, value2);
		System.out.print(attribute2);
		System.out.print(value2);
	}

	public void Requestbodytype() {
		httpRequest.body(requestParams.toJSONString());
	}
	
	public void RequestbodytypeJson(JSONObject jsonObject) {
		httpRequest.body(jsonObject.toString());
	
	}

	public void Response_POST(String url) {
		response = httpRequest.post(url);
		System.out.println("Response: "+response.asString());
	}
	
	public void Response_GET(String url) {
		response = httpRequest.get(url);
		System.out.println("Response: "+response.asString());
	}
	
	public void Responsebody() {
		body = response.getBody();
	}

	public int Responsestatuscode() {
		return response.getStatusCode();
	}

	
	public void Assertioncheck() {
	
	}
	
	public void ExtractNodeFromResponse(String nodetext) {
		jsonPathEvaluator = response.jsonPath();
		shopIntegrationToken = jsonPathEvaluator.get(nodetext);
		System.out.println("PartnerClient_UUID: "+shopIntegrationToken);
		//return shopIntegrationToken;
	}
}