package RestAssured.TestAPI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_Connection {
	
	static String uuid_PCA;
	
	public void ConnectDatabase(String token) throws SQLException, ClassNotFoundException {
	
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:10050/growth","root","local");;
	Class.forName("com.mysql.cj.jdbc.Driver");      
	Statement stmt=con.createStatement();  
	ResultSet rs=stmt.executeQuery("select * from partner_client_application where partner_client_id='"+token+"';");
	//System.out.println(rs.findColumn("partner_client_id"));
	while(rs.next())  
	{
		uuid_PCA= rs.getString(1);
		System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+rs.findColumn("partner_client_id"));
	}
	System.out.println("PartnerClientApplication_UUID:  "+uuid_PCA);
	con.close();
	}
}
