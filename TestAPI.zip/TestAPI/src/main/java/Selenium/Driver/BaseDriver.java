package Selenium.Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import RestAssured.TestAPI.RestAssured_Functions;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseDriver extends RestAssured_Functions{

	public static WebDriver driver;
	
	@Test
	public WebDriver DriverSetup() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		return driver;
	}
	

}
