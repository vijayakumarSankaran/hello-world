package Selenium.Driver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Selenium_Functions extends BaseDriver{
	
	
	@Test
	public WebDriver DropDown_Selector(WebDriver driver, WebElement Element, String value) {
		Select dropdown = new Select(Element);
		dropdown.selectByValue(value);
		return driver;
	}
	
	@Test
	public WebDriver KeyPress_Event(WebDriver driver) {
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ESCAPE).build().perform();
		return driver;
	}
	
	@Test
	public WebDriver Maximize_Window(WebDriver driver) {
		driver.manage().window().maximize();
		return driver;
	}
	
	@Test
	public WebDriver DeleteAll_Cookies(WebDriver driver) {
		driver.manage().deleteAllCookies();
		return driver;
	}
	
	@Test
	public WebDriver ImplicitWait(WebDriver driver, int seconds) {
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
		return driver;
	}
	
	@Test
	public WebDriver LaunchURL_Browser(WebDriver driver, String url) {
		driver.get(url);
		return driver;
	}
	
}
