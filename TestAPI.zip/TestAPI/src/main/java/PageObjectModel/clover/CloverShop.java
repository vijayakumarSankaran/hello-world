package PageObjectModel.clover;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CloverShop{
	
	public WebDriver driver;
	
	public CloverShop(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
		System.out.println(driver);
		
	}
	
	@FindBy(className="cta-button--20YKP")
	public WebElement ShopNow;
	
	@FindBy(className="tile-controls--2lW31")
	public WebElement ShopFlex;
	
	@FindBy(xpath="//*[@class='shop-product-header-container__button btn btn--green']")
	public WebElement BuyNow;
	
	@FindBy(xpath="//*[@class='customize-order-summary__order-button btn btn--green']")
	public WebElement AddToCart;
	
	@FindBy(xpath="//*[@class='accessories-upsell__forward-link btn btn--green']")
	public WebElement ContinueToCart;

	@FindBy(xpath="//*[@class='cart-summary__btn btn btn--green']")
	public WebElement Next;
	
	@FindBy(xpath="(//*[@class='mdc-text-field__input'])[1]")
	public WebElement Email;
	
	@FindBy(xpath="(//*[@class='mdc-text-field__input'])[2]")
	public WebElement MotherMaidenName;
	
	@FindBy(xpath="//input[@class='mdc-checkbox__native-control']")
	public WebElement ICertify;
	
	
	@FindBy(xpath="//*[@class='form__button btn btn--green']")
	public WebElement Continue;
	
	@FindBy(xpath="//input[@id='places-autocomplete']")
	public WebElement AddressLine1;
	
	@FindBy(xpath="(//input[@class='mdc-text-field__input'])[2]")
	public WebElement StateName;
	
	@FindBy(xpath="(//input[@class='mdc-text-field__input'])[3]")
	public WebElement Zip;
	
	@FindBy(xpath="//select[@class='mdc-select__native-control']")
	public WebElement StateCode;
	
	@FindBy(xpath="//button[@class='form__button btn btn--green']")
	public WebElement LastContinue;
	
	public WebElement ShopNow() {
		return ShopNow;
	}
	public WebElement ShopFlex() {
		return ShopFlex;
	}
	public WebElement BuyNow() {
		return BuyNow;
	}
	public WebElement AddToCart() {
		return AddToCart;
	}
	public WebElement ContinueToCart() {
		return ContinueToCart;
	}
	public WebElement Next() {
		return Next;
	}
	public WebElement Email() {
		return Email;
	}
	public WebElement MotherMaidenName() {
		return MotherMaidenName;
	}
	public WebElement Continue() {
		return Continue;
	}
	public WebElement AddressLine1() {
		return AddressLine1;
	}
	public WebElement StateName() {
		return StateName;
	}
	public WebElement Zip() {
		return Zip;
	}
	public WebElement StateCode() {
		return StateCode;
	}
	public WebElement LastContinue() {
		return LastContinue;
	}
	public WebElement ICertify() {
		return ICertify;
	}
	
}
